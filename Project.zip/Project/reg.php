<?php
require 'connecttodb.php';

if (isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["confirmPassword"])) {

    $name = mysqli_real_escape_string($db, $_POST["name"]);
    $email = mysqli_real_escape_string($db, $_POST["email"]);
    $password = md5((mysqli_real_escape_string($db, $_POST["password"])));
    $confirmPassword = md5((mysqli_real_escape_string($db, $_POST["confirmPassword"])));
    if ($password !== $confirmPassword) {
        echo "Error: Passwords do not match.";
        exit();
    } else {
        $pass = md5($password);
        $pass = md5($password);
        $query = "INSERT INTO users (username, email, password) VALUES ('$name', '$email', '$password')";
        mysqli_query($db, $query) or die(mysqli_error($db));
    }
}

?>
<html>

<head>
<link
        href="https://fonts.googleapis.com/css2?family=Concert+One&family=Flow+Circular&family=Luckiest+Guy&family=Poppins:wght@300;400;500;600;700&family=Righteous&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymo us" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="login.css">
</head>

<body style=" width: 100%;
    background: linear-gradient(360deg , rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(img/backgroundlogin1.jpg);
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;;
    height=100vh;">
    <?php
    include("login.html");
    ?>
    <section class="loginnnnn">
        <form action="reg.php" method="POST">
            <div class="login-container" id="signup">
                <div class="header">
                    <h1 class="h1">SIGNUP</h1>
                    <p class="p">Welcome to StudentHub360</p>
                </div>
                <div class="body">
                    <div class="info">
                        <i class="fa-solid fa-envelope"></i>
                        <input class="input" name="email" type="email" id="email" placeholder="Email" required>
                    </div>
                    <div class="info">
                        <i class="fa-solid fa-user"></i>
                        <input class="input" name="name" type="text" id="signup-name" placeholder="Create your username"
                            required>
                    </div>
                    <div class="info">
                        <i class="fa-solid fa-lock"></i>
                        <input class="input" name="password" type="password" id="signup-password"
                            placeholder="Create Password" required>
                    </div>
                    <div class="info">
                        <i class="fa-solid fa-lock"></i>
                        <input class="input" name="confirmPassword" type="password" id="signup-conpassword"
                            placeholder="Confirm Password" required>
                    </div>

                    <div class="remember">
                        <input type="checkbox" id="check">
                        <label>Agree to our Terms& Conditions</label>

                    </div>
                    
                        <input type="submit" value="Register" style="  background-color: goldenrod;
    font-size: 17px;
    padding: 10px 120px;
    display:flex;
    align=items:center;
    justify-content:center;
    margin-top:20px;
    cursor:pointer;
    border:0;
    color:rgb(23, 23, 113);
    font-weight:600;
    ">
               
                    <div class="para">
                        <p class="p">Already have an Account?</p><a href="login.php"><span class="span" id="login-btn2">Sign in</span></a>
                    </div>
                </div>
            </div>


        </form>
    </section>
</body>

</html>