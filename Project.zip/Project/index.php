<?php
include('connecttodb.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>StudentHub360</title>
  <link rel="stylesheet" href="landingpage.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Concert+One&family=Flow+Circular&family=Luckiest+Guy&family=Poppins:wght@300;400;500;600;700&family=Righteous&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="landing.js" defer></script>
</head>

<body>
  <?php
  include('nav.html');
  ?>
  <section id="home">
    <div class="container">
      <h1>Unleash AI's academic magic<br> Your ultimate university <span>Chatbot Companion!</span></h1>
      <p>Elevate your university journey with AI-powered support.</p>
      <!-- <div class="btn"> -->
        <!-- Instead of linking directly to chatbot.php, use a button with an ID -->
        <!-- <button id="startConversationBtn">Start Conversation</button> -->
        <!-- Removed the href attribute and arrow icon -->
      <!-- </div> -->
    </div>
    </div>
    <div id="slider-wrapper">
      <div class="slider">
        <div class="slide first">
          <img style="filter: brightness(1);" src="img/background1.jpg" alt="age 1">
        </div>
      </div>
    </div>
  </section>

  <!-- Include pt code for Start Conversation button -->
  <script>
  // Wait for the DOM content to be fully loaded
  document.addEventListener("DOMContentLoaded", function () {
    const startConversationBtn = document.getElementById("startConversationBtn");
    const chatbotContainer = document.querySelector(".chatbot-container");

    // Function to toggle the visibility of the chatbot
    const toggleChatbot = () => {
      chatbotContainer.classList.toggle("show-chatbot");
    };

    // Event listener for the "Start Conversation" button
    startConversationBtn.addEventListener("click", toggleChatbot);
  });
</script>
</body>

</html>

  <section id="about">
    

    <header>
      <p>About Us</p>
      <h1>Best <span>Student</span> Experience</h1>
    </header>
    <div class="items">
      <div class="left-about">
        <img src="img/AI-Education.webp" alt="image">
      </div>
      <div class="right-about">
        <div class="top"><span>About</span>
        </div>
        <p>StudentHub360 is a dynamic online platform designed to provide students with 
comprehensive support and resources, fostering academic success, and personal 
growth.
          <br><br> As a basic prototype, the project will be built as a website platform which will 
provide various types of services for all students in need.
        </p>
        <div class="btn-2">
          <a href="about.php">
            <button class="btn2">Learn More</button>
            <i class="fa-solid fa-arrow-up-right-from-square"></i>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- <header>
    <p>Chat</p>
    <h1>Ready to answer <span>Your Questions</span></h1>
    <div class="chatbot-container">
    <div class="message-container">
      <div class="user-message">
        Hello, how can I assist you?
      </div>
    </div>
    <div class="message-container">
      <div class="bot-message">
        Welcome! How can I help you today?
      </div>
    </div>
    <div class="message-container">
      <div class="user-message">
        I have a question about your products.
      </div>
    </div>
    <div class="message-container">
      <div class="bot-message">
        Sure, I'll do my best to assist you. What's your question?
      </div>
    </div>
    Add more messages here -->
    
    <!-- <div class="input-container">
      <input type="text" class="input-field" placeholder="Type your message">
      <button class="send-button"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>

    </div>
  </div>
  </div>
</section> -->
  

 
  <section class="reviews" id="reviews">
    <header>
      <p>REVIEWS</p>
      <h1>What our <span>Students</span> Say</h1>
    </header>
    <div class="container-reviews">
      <div class="review">
        <header>
          <img src="img/face1.jpg" alt="">
          <div class="content">
            <h2>John Smith</h2>
            <div class="stars">
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star-half-stroke half"></i>
            </div>
          </div>
        </header>
        <div class="text">
          <p> "This chatbot has revolutionized how I communicate with my professors. It provides quick access to their emails and office hours, saving me time and ensuring effective communication. A game-changer for any student seeking support!"</p>
        </div>
      </div>
      <div class="review">
        <header>
          <img src="img/face3.jpg" alt="">
          <div class="content">
            <h2>Alena Trump</h2>
            <div class="stars">
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star-half-stroke half"></i>
            </div>
          </div>
        </header>
        <div class="text">
          <p>"Gone are the days of struggling to reach out to my professors. This chatbot has made it incredibly convenient to access their contact details and office hours. It has streamlined my communication with faculty and enhanced my overall university experience." </p>
        </div>
      </div>
      <div class="review">
        <header>
          <img src="img/face2.webp" alt="">
          <div class="content">
            <h2>Micheal Ballack</h2>
            <div class="stars">
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star"></i>
              <i class="fa-sharp fa-solid fa-star-half-stroke half"></i>
            </div>
          </div>
        </header>
        <div class="text">
          <p>"I can't thank this chatbot enough for simplifying the process of connecting with my professors. With just a few clicks, I can easily find their contact information and office hours. It has made scheduling meetings and seeking guidance a breeze. A must-have tool!"<br><br></p>
        </div>
      </div>
    </div>
  </section>
  <section class="contact" id="contact">
    
    <div class="contactsss">
      <div class="right-contact">
        <form action="https://formspree.io/f/mpzvyebr" method="POST">
          <div class="social">
            <h1>Leave <span>Your </span> Feedback</h1>
            <ul>
              <li><a href="https://www.instagram.com/abedtenchassi_?igsh=amsxMmlzOGl6dXc2&utm_source=qr"><i
                    class="fa-brands fa-instagram"></i></a></li>
              <li><a href="https://www.facebook.com/abdulrhmanenchassi.enchassi?mibextid=LQQJ4d"><i class="fa-brands fa-facebook"></i></a></li>
              <li><a href="tel:71145310"><i class="fa-brands fa-whatsapp"></i></a></li>
              <li class="location"><a
                  href="https://www.google.com/maps/place/Beirut,+Lebanon/@33.890368,35.503653,14z/data=!4m6!3m5!1s0x151f17215880a78f:0x729182bae99836b4!8m2!3d33.8937913!4d35.5017767!16zL20vMDlianY?hl=en-US"><i
                    class="fa-sharp fa-solid fa-location-dot"></i></a></li>
            </ul>
          </div>
          <input type="text"  name=" " class="inputtt" id="fname" placeholder="First Name" required>
          <br>
          <input type="text" name=" " class="inputtt" id="lname" placeholder="Last Name" required>
          <br>
          <input type="email" name=" " class="inputtt" id="email-contact" placeholder="Email" required>
          <br>
          <textarea name=" " id="" cols="30" rows="10" required placeholder="Message"></textarea>
          <br>
          <input type="submit" value="Send" class="send">

      </div>

      </form>
    </div>
    </div>
  </section>
  <?php

  include('footer.html');

  ?>
  <style>
    html {
  scroll-behavior: smooth;
}

body {
  overflow-x: hidden;
  background-color: var(--white);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

:root {
  --black: rgb(29, 26, 26);
  --darkblue: rgb(23, 23, 113);
  --lighttextcolor: rgb(235, 228, 228);
  --white: rgb(234, 232, 232);
  --lightblue:rgb(0, 179, 255);
}
#home {
  position: relative;
  height: 100vh;
  width: 100%;
}

#home .container {
  position: absolute;
  top: 37%;
  padding: 0px 90px;
  z-index: 2;
}

#home .container h1 {
  font-size: 30px;
  color: var(--lighttextcolor);
  
}

#home .container h1 span {
  color: var(--lightblue);
}

#home .container p {
  margin-top: 10px;
  margin-bottom: 20px;
  font-size: 18px;
  color: rgb(165, 162, 162);
  font-weight: 600;
}

.btn {
  margin-top: 10px;
  border: 1px solid var(--white);
  width: fit-content;
  padding: 0px 15px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  position: relative;
  transition: all 0.3s;
  height :50px;
}

.btn button {
  padding: 10px 40px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  background: transparent;
  border: 0;
  color: var(--lighttextcolor);
  transition: all 0.6s;
}

.btn a i {
  color: var(--lightblue);
  transition: all 0.6s;
}

.btn::after {
  content: '';
  height: 100%;
  width: 0%;
  position: absolute;
  background-color: var(--lightblue);
  bottom: 0;
  margin: auto;
  z-index: -3;
  transition: all 0.6s;
}

.btn:hover::after {
  width: 100%;
}

.btn:hover button,
.btn:hover i {
  color: var(--white);
}
i::before{
  content:"";
}

#home .container .btn:active {
  transform: scale(0.7);
}

@media (max-width:985px) {
  #home .container h1 {
    font-size: 28px;
  }

  #home .container {
    padding: 0px 30px;
  }

  #home .container p {
    font-size: 15px;
  }

  .btn button {
    padding: 13px 20px;
  }
}


#slider-wrapper {
  height: 100vh;
  overflow: hidden;
}

.slider {
  display: flex;

}

.slide {
  flex-shrink: 0;
  width: 100vw;
  height: 100vh;

}

.slide img {
  width: 100%;
  height: 100%;
  object-fit: cover;


}

.first {
  margin-left: 0;

}

.nav-manual {
  z-index: 1001;
  position: absolute;
  top: 90%;
  width: 200px;
  margin: auto;
  left: 42%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.manual-btn {
  margin-right: 5px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 3px 50px;
  background-color: rgb(155, 154, 154);
  border: 0;
  border-radius: 10px;
  cursor: pointer;
  transition: all .4s;
}

.manual-btn:hover {
  background-color: goldenrod;
}

@media (max-width:985px) {
  .nav-manual {

    left: 22%;
  }
}

#about {
  height: fit-content;
  width: 100%;
  padding: 0px 90px;
  background-color: var(--white);
}

#about .items {
  display: flex;

}

#about header {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  margin-bottom: 30px;
  padding-top: 110px;
}

#about header h1 {
  font-size: 35px;
  
}

#about .items .left-about {
  width: 50%;
  height: 500px;
  margin-right: 30px;
  
}

#about .items .left-about img {
  width: 100%;
  height: 90%;
  border-radius:20px;
}

#about .items .right-about {
  width: 40%;
  height: auto;
}

#about .items .right-about span {
  color: var(--lightblue);
  font-weight: 600;
  font-size: 19px;
}

.top {
  margin-bottom: 40px;
}

#about .items .right-about p {
  font-size: 18.60px;
}

 .btn-2 {
  margin-top: 15px;
  border: 1px solid goldenrod;
  width: fit-content;
  display: flex;
  align-items: center;
  cursor: pointer;
  position: relative;
  transition: all 0.3s;
  z-index: 2;
  background-color: goldenrod;
  margin-bottom: 20px;
  

}

.btn-2 .btn2 {
  padding: 10px 50px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 600;
  background-color: transparent;
  border: 0;
  color: var(--darkblue);
  transition: all 0.6s;
}

 .btn-2 i {
  color: var(--darkblue);
  text-decoration: none;
  transition: 0.6s;
  position: absolute;
  right: 20px;
  top: 30%;
}

.btn-2 ::after {
  content: '';
  height: 100%;
  width: 0%;
  left: 0;
  position: absolute;
  background-color: var(--lightblue);
  bottom: 0;
  margin: auto;
  z-index: -1;
  transition: all 0.6s;
}

.btn-2 :hover::after {
  width: 100%;
  font-size: 25px;
}

.btn-2 :hover button,
.btn-2 :hover i {
  color: var(--white);
}

@media (max-width:985px) {
  #about {
    padding: 0px 30px;
  }

  #about header {
    padding-top: 60px;
  }

  #about h1 {
    text-align: center;
    font-size: 30px;
  }

  #about .items {
    flex-direction: column;
  }

  #about .items .left-about {
    width: 100%;
    margin-right: 0;
    margin-bottom: -20px;
  }

  #about .items .right-about {
    width: 100%;

  }

  #about .items .right-about p {
    font-size: 16px;
  }

  .top {
    margin-bottom: 20px;
  }
}

.reviews {
  min-height: 100vh;
  padding: 20px 90px;
  width: 100%;
}

.reviews header {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  width: 100%;
  margin-bottom: 30px;
  padding-top: 70px;
}

.reviews header h1 {
  font-size: 35px;
}

.reviews .container-reviews {
  display: flex;
  margin-left: 50px;
  justify-content: center;
  align-items: center;
  width: 100%;
}

.reviews .container-reviews .review {
  width: 32%;
  margin-right: 80px;
  text-align: center;
  background-color: silver;
  padding: 0px 20px 20px 20px;
  border-radius: 20px;
  height: fit-content;

}

.reviews .container-reviews .review p {
  font-size: 15px;
}

.reviews .container-reviews .review header img {
  width: 150px;
  height: 150px;
  border-radius: 50%;
}

.content {
  padding-top: 40px;
}

.review i {
  color: goldenrod;
}

span {
  color: goldenrod;
}

@media (max-width:985px) {
  .reviews .container-reviews {
    display: flex;
    flex-direction: column;

    justify-content: center;
    align-items: center;
    width: 100%;
  }

  .reviews {
    padding-left: 30px;
    padding-right: 30px;
  }

  .reviews .container-reviews .review {
    width: 100%;
    margin-top: 40px;
    background-color: silver;


  }

  .reviews header h1 {
    font-size: 30px;
  }
}

.contact {
  min-height: 100vh;
  padding: 80px 90px;
  width: 100%;
}

.contactsss {
  margin-top: 50px;
  display: flex;
  align-items: center;

}

.left-contact {
  width: 50%;
  height: 90vh;
  margin-right: 40px;
}

.left-contact iframe {
  width: 100%;
  height: 100%;
}

.right-contact {
  margin-top: 10px;
  width: 50%;

}

header {
  text-align: center;
  width: 100%;
}

header h1 {
  font-size: 35px;
}

.right-contact .inputtt {
  background: transparent;
  border: 2px solid black;
  width: 70%;
  height: 40px;
  padding-left: 10px;
  margin-bottom: 20px;
}

.right-contact .inputtt::placeholder {
  color: black;

}

.right-contact .inputtt:focus {
  outline-color: goldenrod;
}

.right-contact textarea {
  background: transparent;
  border: 2px solid black;
  width: 70%;
  height: 200px;
  margin-bottom: 20px;
  padding-left: 10px;
}

textarea:focus {
  outline-color: goldenrod;
}

textarea::placeholder {
  color: black;
}

.social {
  margin-bottom: 20px;
}

.social h1 {
  font-size: 33px;
}

.social ul {
  margin-top: 15px;
  list-style: none;
  display: flex;
  align-items: center;
  gap: 25px;
  margin-right:50px;
}

.social ul li {
  padding: 10px 10px;
  height: 50px;
  width: 50px;
  text-align: center;
  font-size: 21px;
  background-color: var(--lightblue);
  transition: all 0.4s;
  cursor: pointer;
 
}

.social ul li a {
  text-decoration: none;
  color: var(--white);
}

.social ul li:hover {
  background-color: goldenrod;
}

.social ul li:hover a {
  color: var(--darkblue);
}

.send {
  width: 30%;
  padding: 10px 40px;
  font-size: 15px;
  font-weight: 600;
  text-align: center;
  margin: 0;
  cursor: pointer;
  background-color: goldenrod;
  color: var(--darkblue);
  border: 0;
  border-radius: 7px;
  transition: all 0.4s;
  margin-left: 0px;
  margin-right: 210px;
}

.send:active {
  transform: scale(0.8);
}

.send:hover {
  background: rgb(211, 182, 18);
}
.location{
  display: none;
}
@media (max-width:985px) {
  .contact {
    padding: 20px 30px;
  }

  .contactsss {
    flex-direction: column-reverse;
    
  }

  .left-contact {
     display: none;
  }
  .location{
    display: block;
  }
  .social {
    text-align: left;
  }

  .social h1 {
    font-size: 17px;
  }

  .left-contact iframe {
    width: 100%;
    height: 100%;
  }

  .right-contact {
    margin: auto;
    padding: 0;
    margin-top: 10px;
    width: 100%;
    align-items: center;
    justify-content: left;

  }

  header h1 {
    font-size: 30px;
  }
  body {
    overflow-x: hidden;
  }
}

footer {
  text-align: center;
  width: 100%;
  background-color: black;
  height: 70px;
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
}
.categories {
  min-height: 100vh;
  width: 100%;

}
.cat-grid {
  padding: 40px 90px;
  min-height: 100vh;
  width: 100%;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
   column-gap: 30px;
   row-gap: 30px;
   background-color: transparent;
   transition: all 0.6s;
   
}
.image-item {
  text-align: center;
  cursor: pointer;
  height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  background-color: transparent;
   transition: all 0.6s;
  box-shadow: 0px 0px 9px 5px var(--black);
-webkit-box-shadow: 0px 0px 9px 5px var(--black);
-moz-box-shadow: 0px 0px 9px 5px var(--black);
}
.image-item:hover {
  background-color: goldenrod;
}
.cat-a {
  text-decoration: none;
  color: black;
}
.cat-img {
  width: 100px;
}
.cat-header {
  margin-top: 50px;
  width: 100%;
  height: 20%;
  text-align: center;
  font-size: 30px;
}
@media (max-width :985px) {
  .cat-grid {
    grid-template-columns: repeat(1, 1fr);
    padding:  30px;
  }
  .image-item {
    width: 100%;
  }
}

.pat-img {
  width: 400px;
  transition: all 0.6s;
}
.prod-footer {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-around;
}
.product-item {
  position: relative;
  width: fit-content;
  height: 400px;
  transition: all 0.6s;
  box-shadow: 0px 0px 9px 5px var(--black);
-webkit-box-shadow: 0px 0px 9px 5px var(--black);
-moz-box-shadow: 0px 0px 9px 5px var(--black);
  
} 
.pat-grid {
  padding-top: 50px;
  padding-left: 30px;
  padding-right: 30px;
  min-height: 100vh;
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  background-color: transparent;
  transition: all 0.6s;
   
}
.top-products {
  padding-left: 50px;
  padding-right: 50px;
  padding-top: 100px;
  
}
.product-detail {
  padding-top: 40px;
  display: flex;
  flex-direction: column;

  
}
.descr {
  width: 30%;
}
.deeeeee {
  display: flex;
  align-items: center;
}
body {
      background-color: var(--white);
      font-family: 'Poppins', sans-serif; 
    }
    
    .chatbot-container {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
      max-width: 400px;
      margin: 20px auto;
      padding: 20px;
    }
    
    .message-container {
      display: flex;
      align-items: flex-start;
      margin-bottom: 10px;
    }
    
    .user-message {
      background-color: var(--lightblue);
      color: white;
      padding: 10px;
      border-radius: 5px;
      margin-right: 10px;
    }
    
    .bot-message {
      background-color: white;
      color: black;
      padding: 10px;
      border-radius: 5px;
      margin-left: 10px;
    }
    
    .input-container {
      display: flex;
      margin-top: 20px;
    }
    
    .input-field {
      flex-grow: 1;
      padding: 10px;
      border: none;
      border-radius: 5px;
    }
    
    .send-button {
      background-color: var(--lightblue);
      color: white;
      padding: 10px;
      border: none;
      border-radius: 5px;
      margin-left: 10px;
      cursor: pointer;
      width:50px;
      border-radius: 200px 200px 200px 200px;
-webkit-border-radius: 200px 200px 200px 200px;
-moz-border-radius: 200px 200px 200px 200px;
    }
  </style>
  
</body>

</html>