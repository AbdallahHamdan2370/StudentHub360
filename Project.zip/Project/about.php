<?php
include('connecttodb.php');
?>

<html>

<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Concert+One&family=Flow+Circular&family=Luckiest+Guy&family=Poppins:wght@300;400;500;600;700&family=Righteous&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymo us" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="landingpage.css">
</head>

<body>
    <div>
        <?php
        include('nav.html');
        ?>
    </div>
    <div class="about-page">
        <header>
            
            <h1>About <span>Us</span></h1>
        </header>
        <div class="main">
            <div class="left-about">
                <h3>What is <span>StudentHub360</span> ?</h3>
                <p>Welcome to StudentHub360, a dynamic online platform dedicated to empowering students and fostering their academic success and personal growth. Designed as a comprehensive support system, our website serves as a one-stop destination for students in need. <br>
                    <br>

                    As a basic prototype, StudentHub360 will be developed as a cutting-edge website platform, offering a wide range of services tailored to meet the diverse needs of students. We understand that navigating university life can sometimes be challenging, which is why we are committed to providing the necessary resources and assistance to help students thrive.<br>
                    <br>

                    But our platform isn't just limited to students. We recognize that instructors play a vital role in shaping the educational experience, so we've created a powerful tool that enhances their flexibility and efficiency. With StudentHub360, instructors can streamline their workflows, access valuable resources, and engage in meaningful interactions with their students.<br>
                    <br>

                    What sets us apart from traditional information-providing websites is our commitment to innovation. At the core of our platform lies an advanced chatbot, revolutionizing the student experience. Our chatbot acts as a virtual assistant, capable of answering a wide range of questions and providing real-time support. No longer will students need to wait in line or schedule appointments with advisors or instructors. With our chatbot, help is just a message away.<br>
                    <br>
                    Our team is dedicated to training the chatbot to handle an array of inquiries, ensuring that students receive accurate and helpful responses. Whether it's about course information, deadlines, study tips, or general university queries, our chatbot is here to provide instant assistance, 24/7.<br>
                    <br>

                    

                </p>
            </div>
            <div class="right-about">
                <img src="img/about.avif" alt="">
            </div>
        </div>
    </div>
    <div class="footer">
        <?php
        include('footer.html');
        ?>
    </div>

</body>
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        text-decoration: none;
    }

    div {
        height: fit-content;
    }

    body {
        min-height: 100vh;
    }

    .about-page {
        padding: 0px 90px;
        min-height: 80vh;
        position: absolute;
        top: 20%;
        width: 100%;
    }

    .about-page header {
        text-align: left;
        width: 100%;
    }

    header h1 {
        font-size: 40px;
    }

    .main {
        display: flex;
        position: relative;
    }

    .right-about img {
        width: 100%;
        height: 400px;
    }

    .left-about {
        margin-top: 30px;
        width: 55%;
        margin-right: 20px;
    }

    .right-about {
        width: 45%;
        margin-top: 80px;
    }

    h3 {
        margin-bottom: 20px;
    }
    .footer {
        position: absolute;
        top: 200%;
        width: 100%;
    }
    @media (max-width:985px) {
        .main {
            flex-direction: column-reverse;
        }

        .right-about {
            width: 100%;
            margin-top: 30px;
        }

        .left-about {
            margin-top: 30px;
            width: 100%;

        }

        .about-page {
            padding: 0 30px;
        }
        .footer {
            top: 280%;
        }
    }
   
</style>

</html>