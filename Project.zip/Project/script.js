const chatbotToggler = document.querySelector(".chatbot-toggler");
const closeBtn = document.querySelector(".close-btn");
const chatbox = document.querySelector(".chatbox");
const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector(".chat-input span");

let userMessage = null; // Variable to store user's message
const inputInitHeight = chatInput.scrollHeight;

const createChatLi = (message, className) => {
    // Create a chat <li> element with passed message and className
    const chatLi = document.createElement("li");
    chatLi.classList.add("chat", `${className}`);
    let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
    chatLi.innerHTML = chatContent;
    chatLi.querySelector("p").textContent = message;
    return chatLi; // return chat <li> element
}

const generateResponse = (chatElement, userMessage) => {
    // JSON file containing responses based on user messages
    const responsesFile = 'responses.json';
    const messageElement = chatElement.querySelector("p");

    // Load responses from JSON file
    fetch(responsesFile)
        .then(response => response.json())
        .then(responses => {
            // Find response corresponding to the user message
            const response = responses[userMessage.toLowerCase()];
            if (response) {
                // Set the response as paragraph text
                messageElement.textContent = response;
            } else {
                // If no response found, display a default message
                messageElement.textContent = "I'm sorry, I don't understand that.";
            }
        })
        .catch(() => {
            // Handle errors
            messageElement.classList.add("error");
            messageElement.textContent = "Oops! Something went wrong. Please try again.";
        })
        .finally(() => chatbox.scrollTo(0, chatbox.scrollHeight));
}

const handleChat = () => {
    userMessage = chatInput.value.trim(); // Get user entered message and remove extra whitespace
    if(!userMessage) return;

    // Clear the input textarea and set its height to default
    chatInput.value = "";
    chatInput.style.height = `${inputInitHeight}px`;

    // Append the user's message to the chatbox
    chatbox.appendChild(createChatLi(userMessage, "outgoing"));
    chatbox.scrollTo(0, chatbox.scrollHeight);
    
    setTimeout(() => {
        // Display "Thinking..." message while waiting for the response
        const incomingChatLi = createChatLi("Thinking...", "incoming");
        chatbox.appendChild(incomingChatLi);
        chatbox.scrollTo(0, chatbox.scrollHeight);
        generateResponse(incomingChatLi, userMessage);
    }, 600);
}

chatInput.addEventListener("input", () => {
    // Adjust the height of the input textarea based on its content
    chatInput.style.height = `${inputInitHeight}px`;
    chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
    // If Enter key is pressed without Shift key and the window 
    // width is greater than 800px, handle the chat
    if(e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
        e.preventDefault();
        handleChat();
    }
});

sendChatBtn.addEventListener("click", handleChat);
closeBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));

// Wait for the DOM content to be fully loaded
document.addEventListener("DOMContentLoaded", function () {
    const startConversationBtn = document.getElementById("startConversationBtn");
    const chatbotContainer = document.querySelector(".chatbot");

    // Function to toggle the visibility of the chatbot
    const toggleChatbot = () => {
        chatbotContainer.classList.toggle("show-chatbot");
    };

    // Event listener for the "Start Conversation" button
    startConversationBtn.addEventListener("click", toggleChatbot);
});
5





// const chatbotToggler = document.querySelector(".chatbot-toggler");
// const closeBtn = document.querySelector(".close-btn");
// const chatbox = document.querySelector(".chatbox");
// const chatInput = document.querySelector(".chat-input textarea");
// const sendChatBtn = document.querySelector(".chat-input span");

// let userMessage = null; // Variable to store user's message
// const inputInitHeight = chatInput.scrollHeight;

// const createChatLi = (message, className) => {
//     // Create a chat <li> element with passed message and className
//     const chatLi = document.createElement("li");
//     chatLi.classList.add("chat", `${className}`);
//     let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
//     chatLi.innerHTML = chatContent;
//     chatLi.querySelector("p").textContent = message;
//     return chatLi; // return chat <li> element
// }

// const generateResponse = (chatElement, userMessage) => {
//     // JSON file containing responses based on user messages
//     const responsesFile = 'responses.json';
//     const messageElement = chatElement.querySelector("p");

//     // Load responses from JSON file
//     fetch(responsesFile)
//         .then(response => response.json())
//         .then(responses => {
//             // Find response corresponding to the user message
//             const response = responses[userMessage.toLowerCase()];
//             if (response) {
//                 // Set the response as paragraph text
//                 messageElement.textContent = response;
//             } else {
//                 // If no response found, display a default message
//                 messageElement.textContent = "I'm sorry, I don't understand that.";
//             }
//         })
//         .catch(() => {
//             // Handle errors
//             messageElement.classList.add("error");
//             messageElement.textContent = "Oops! Something went wrong. Please try again.";
//         })
//         .finally(() => chatbox.scrollTo(0, chatbox.scrollHeight));
// }

// const handleChat = () => {
//     userMessage = chatInput.value.trim(); // Get user entered message and remove extra whitespace
//     if(!userMessage) return;

//     // Clear the input textarea and set its height to default
//     chatInput.value = "";
//     chatInput.style.height = `${inputInitHeight}px`;

//     // Append the user's message to the chatbox
//     chatbox.appendChild(createChatLi(userMessage, "outgoing"));
//     chatbox.scrollTo(0, chatbox.scrollHeight);
    
//     setTimeout(() => {
//         // Display "Thinking..." message while waiting for the response
//         const incomingChatLi = createChatLi("Thinking...", "incoming");
//         chatbox.appendChild(incomingChatLi);
//         chatbox.scrollTo(0, chatbox.scrollHeight);
//         generateResponse(incomingChatLi, userMessage);
//     }, 600);
// }

// chatInput.addEventListener("input", () => {
//     // Adjust the height of the input textarea based on its content
//     chatInput.style.height = `${inputInitHeight}px`;
//     chatInput.style.height = `${chatInput.scrollHeight}px`;
// });

// chatInput.addEventListener("keydown", (e) => {
//     // If Enter key is pressed without Shift key and the window 
//     // width is greater than 800px, handle the chat
//     if(e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
//         e.preventDefault();
//         handleChat();
//     }
// });

// sendChatBtn.addEventListener("click", handleChat);
// closeBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
// chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));

// // Wait for the DOM content to be fully loaded
// document.addEventListener("DOMContentLoaded", function () {
//     const startConversationBtn = document.getElementById("startConversationBtn");
//     const chatbotContainer = document.querySelector(".chatbot");

//     // Function to toggle the visibility of the chatbot
//     const toggleChatbot = () => {
//         chatbotContainer.classList.toggle("show-chatbot");
//     };

//     // Event listener for the "Start Conversation" button
//     startConversationBtn.addEventListener("click", toggleChatbot);
// });

